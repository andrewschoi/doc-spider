function sayHello(name) {
  console.log(`hello ${name}!`);
}
